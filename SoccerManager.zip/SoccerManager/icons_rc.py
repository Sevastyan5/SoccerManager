# Resource object code (Python 3)
# Created by: object code
# Created by: The Resource Compiler for Qt version 6.6.3
# WARNING! All changes made in this file will be lost!

from PySide6 import QtCore

qt_resource_data = b"\
\x00\x00\x01\x97\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 width=\x2210\
0\x22 height=\x22100\x22 \
viewBox=\x220 0 24 \
24\x22 fill=\x22none\x22 \
stroke=\x22#ffffff\x22\
 stroke-width=\x222\
\x22 stroke-linecap\
=\x22round\x22 stroke-\
linejoin=\x22round\x22\
 class=\x22feather \
feather-calendar\
\x22><rect x=\x223\x22 y=\
\x224\x22 width=\x2218\x22 h\
eight=\x2218\x22 rx=\x222\
\x22 ry=\x222\x22></rect>\
<line x1=\x2216\x22 y1\
=\x222\x22 x2=\x2216\x22 y2=\
\x226\x22></line><line\
 x1=\x228\x22 y1=\x222\x22 x\
2=\x228\x22 y2=\x226\x22></l\
ine><line x1=\x223\x22\
 y1=\x2210\x22 x2=\x2221\x22\
 y2=\x2210\x22></line>\
</svg>\
\x00\x00\x01\x96\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 width=\x2210\
0\x22 height=\x22100\x22 \
viewBox=\x220 0 24 \
24\x22 fill=\x22none\x22 \
stroke=\x22#ffffff\x22\
 stroke-width=\x222\
\x22 stroke-linecap\
=\x22round\x22 stroke-\
linejoin=\x22round\x22\
 class=\x22feather \
feather-globe\x22><\
circle cx=\x2212\x22 c\
y=\x2212\x22 r=\x2210\x22></\
circle><line x1=\
\x222\x22 y1=\x2212\x22 x2=\x22\
22\x22 y2=\x2212\x22></li\
ne><path d=\x22M12 \
2a15.3 15.3 0 0 \
1 4 10 15.3 15.3\
 0 0 1-4 10 15.3\
 15.3 0 0 1-4-10\
 15.3 15.3 0 0 1\
 4-10z\x22></path><\
/svg>\
\x00\x00\x06\xc6\
<\
?xml version=\x221.\
0\x22 encoding=\x22utf\
-8\x22?>\x0d\x0a<!-- Gene\
rator: Adobe Ill\
ustrator 24.3.0,\
 SVG Export Plug\
-In . SVG Versio\
n: 6.00 Build 0)\
  -->\x0d\x0a<svg vers\
ion=\x221.1\x22 id=\x22Ca\
pa_1\x22 xmlns=\x22htt\
p://www.w3.org/2\
000/svg\x22 xmlns:x\
link=\x22http://www\
.w3.org/1999/xli\
nk\x22 x=\x220px\x22 y=\x220\
px\x22\x0d\x0a\x09 viewBox=\x22\
0 0 800 800\x22 sty\
le=\x22enable-backg\
round:new 0 0 80\
0 800;\x22 xml:spac\
e=\x22preserve\x22>\x0d\x0a<\
style type=\x22text\
/css\x22>\x0d\x0a\x09.st0{fi\
ll:#E61F4B;}\x0d\x0a\x09.\
st1{fill:#FFFFFF\
;}\x0d\x0a</style>\x0d\x0a<g\
>\x0d\x0a\x09<path class=\
\x22st0\x22 d=\x22M421,86\
.2v158.9L552.8,3\
41l129.9-75.6V11\
7.1c-34.9-34.9-7\
6.4-63.3-123-83.\
5L421,86.2z\x22/>\x0d\x0a\
\x09<polygon class=\
\x22st1\x22 points=\x2240\
0,281.8 273.1,37\
4 321.5,523.2 47\
8.4,523.2 526.9,\
374 \x09\x22/>\x0d\x0a\x09<path\
 class=\x22st0\x22 d=\x22\
M506.4,785.4l73.\
9-119.1l-95.6-10\
1.1H315.3l-95.6,\
101.1l74.1,119.2\
C363.6,804.9,436\
.6,804.8,506.4,7\
85.4z\x22/>\x0d\x0a\x09<path\
 class=\x22st1\x22 d=\x22\
M302.4,12.3L400,\
49.3l97.7-37.1C4\
65.5,4.1,432.8,0\
,400,0C367.3,0,3\
34.5,4.1,302.4,1\
2.3z\x22/>\x0d\x0a\x09<path \
class=\x22st0\x22 d=\x22M\
699.2,304.3L569,\
380.1l-51.6,158.\
7L612.2,639l142.\
6-54.6c4.7-9.2,9\
.2-18.6,13.3-28.\
2\x0d\x0a\x09\x09c18.2-42.9,\
28.6-87.7,31.3-1\
32.9L699.2,304.3\
z\x22/>\x0d\x0a\x09<path cla\
ss=\x22st0\x22 d=\x22M282\
.5,538.8l-51.6-1\
58.7l-130.2-75.8\
L0.7,423.7c2.6,4\
2.7,12.1,85.2,28\
.6,126.1c4.6,11.\
4,9.7,22.6,15.3,\
33.4\x0d\x0a\x09\x09L187.9,6\
39L282.5,538.8z\x22\
/>\x0d\x0a\x09<path class\
=\x22st1\x22 d=\x22M717.2\
,643.6l-96.5,37.\
1l-50.2,81C628.8\
,734.2,678.8,693\
.8,717.2,643.6z\x22\
/>\x0d\x0a\x09<path class\
=\x22st1\x22 d=\x22M724.7\
,166.5v102.8l72.\
8,86c-4.1-35.6-1\
3-71-26.8-105.1C\
758.5,220.2,743.\
1,192.2,724.7,16\
6.5z\x22/>\x0d\x0a\x09<path \
class=\x22st1\x22 d=\x22M\
229.5,761.6l-50.\
2-80.9l-96.6-37.\
1C121.1,693.7,17\
1.1,734.1,229.5,\
761.6z\x22/>\x0d\x0a\x09<pat\
h class=\x22st0\x22 d=\
\x22M247.1,341L379,\
245.2V86.2L240.2\
,33.5c-46.5,20.2\
-88,48.6-123,83.\
6v148.2L247.1,34\
1z\x22/>\x0d\x0a\x09<path cl\
ass=\x22st1\x22 d=\x22M2.\
5,355.4l72.8-86V\
166.5c-17,23.8-3\
1.6,49.7-43.3,77\
.3C16.6,279.9,6.\
8,317.4,2.5,355.\
4z\x22/>\x0d\x0a</g>\x0d\x0a</s\
vg>\x0d\x0a\
"

qt_resource_name = b"\
\x00\x03\
\x00\x00x\xc3\
\x00r\
\x00e\x00s\
\x00\x0c\
\x07\xb5\x02G\
\x00c\
\x00a\x00l\x00e\x00n\x00d\x00a\x00r\x00.\x00s\x00v\x00g\
\x00\x09\
\x05\x88\x86\xa7\
\x00g\
\x00l\x00o\x00b\x00e\x00.\x00s\x00v\x00g\
\x00\x0a\
\x09\xca\x11\xe7\
\x00s\
\x00o\x00c\x00c\x00e\x00r\x00.\x00s\x00v\x00g\
"

qt_resource_struct = b"\
\x00\x00\x00\x00\x00\x02\x00\x00\x00\x01\x00\x00\x00\x01\
\x00\x00\x00\x00\x00\x00\x00\x00\
\x00\x00\x00\x00\x00\x02\x00\x00\x00\x03\x00\x00\x00\x02\
\x00\x00\x00\x00\x00\x00\x00\x00\
\x00\x00\x00*\x00\x00\x00\x00\x00\x01\x00\x00\x01\x9b\
\x00\x00\x01\x8f\x9f\xed\xbf^\
\x00\x00\x00\x0c\x00\x00\x00\x00\x00\x01\x00\x00\x00\x00\
\x00\x00\x01\x8f\x9f\xedG;\
\x00\x00\x00B\x00\x00\x00\x00\x00\x01\x00\x00\x035\
\x00\x00\x01\x8f\x9f\xeb\x0e\xbc\
"

def qInitResources():
    QtCore.qRegisterResourceData(0x03, qt_resource_struct, qt_resource_name, qt_resource_data)

def qCleanupResources():
    QtCore.qUnregisterResourceData(0x03, qt_resource_struct, qt_resource_name, qt_resource_data)

qInitResources()
