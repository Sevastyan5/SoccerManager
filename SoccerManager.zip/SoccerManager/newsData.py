class NewsData:
    def __init__(self):
        super(NewsData, self).__init__()
        self.news = ''
        self.link = ''
        self.date = ''
        self.img_path = ''
