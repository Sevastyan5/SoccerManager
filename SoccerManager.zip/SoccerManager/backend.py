import requests
from bs4 import BeautifulSoup
import os
import shutil
from newsData import NewsData
from matchData import MatchData

news_url = "https://www.sports.ru/football/"
matches_url = "https://soccer365.ru/online/"


def clear_dir():
    if os.path.exists(os.path.dirname(__file__) + "\\imgs"):
        shutil.rmtree(os.path.dirname(__file__) + "\\imgs")
    os.mkdir(os.path.dirname(__file__) + "\\imgs")


def load_image(url, filename):
    img = requests.get(url)
    with open(filename, 'wb') as file:
        file.write(img.content)


def get_news():
    clear_dir()
    response = requests.get(news_url)

    if response.status_code == 200:
        soup = BeautifulSoup(response.text, 'lxml')

        news = []
        all_news = soup.findAll('article',
                                class_='js-active js-material-list__blogpost material-list__item clearfix piwikTrackContent')
        count = 0

        for data_ in all_news:
            if count == 5:
                break
            if data_.find('span', class_='content-label content-label--small-top') is None:
                if data_.find('a', class_='h2 material-list__title-link') is not None:
                    current_data = data_.find('a', class_='h2 material-list__title-link')

                    data = NewsData()
                    data.news = str(current_data.text)[1:]
                    data.link = current_data['href']
                    data.date = data_.find('time', class_='time-block time-block_top').text
                    data.img_path = os.path.dirname(__file__) + f"\\imgs\\{str(count)}.jpeg"

                    img_link = data_.find('img', class_='material-list__item-img lazyload')['data-src']
                    load_image(img_link, data.img_path)

                    count += 1
                    news.append(data)
        return news
    else:
        print("There is no internet connection")


def get_matches():
    response = requests.get(matches_url)

    if response.status_code == 200:
        soup = BeautifulSoup(response.text, 'lxml')

        matches = []
        all_championships = soup.findAll("div", class_='live_comptt_bd')

        count = 0

        for championship in all_championships:
            if count == 5:
                break
            count += 1

            all_matches = championship.findAll("div", class_='game_block')
            for match in all_matches:
                if match.find('span', class_='size11') is not None:
                    current_data = championship.find('span', class_='size11')
                    data = MatchData()
                    data.championship = championship.find("span").text
                    data.time = current_data.text
                    teams = match.findAll("div", class_='name')
                    data.team1 = teams[0].find("span").text
                    data.team2 = teams[1].find("span").text
                    data.stage = match.find("div", class_='stage').text

                    matches.append(data)

        return matches

    else:
        print("There is no internet connection")


def get_news_url():
    return news_url


def get_matches_url():
    return matches_url
