# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'main.ui'
##
## Created by: Qt User Interface Compiler version 6.6.3
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QHBoxLayout, QLabel, QMainWindow,
    QPlainTextEdit, QPushButton, QSizePolicy, QSpacerItem,
    QVBoxLayout, QWidget)
import icons_rc

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        if not MainWindow.objectName():
            MainWindow.setObjectName(u"MainWindow")
        MainWindow.resize(800, 600)
        MainWindow.setMinimumSize(QSize(800, 600))
        MainWindow.setMaximumSize(QSize(800, 600))
        MainWindow.setStyleSheet(u"*{\n"
"background: transparent;\n"
"color: transparent;\n"
"}\n"
"#title{\n"
"padding-bottom: 5px;\n"
"}\n"
"#centralwidget{\n"
"background-color: #060B0E;\n"
"}\n"
"#header{\n"
"background-color: #031E28;\n"
"}\n"
"QLabel, QPlainTextEdit, QPushButton{\n"
"color: white;\n"
"border: 0 transparent;\n"
"}\n"
"#news1, #news2, #news3{\n"
"background-color: #031E28;\n"
"border-radius: 10px;\n"
"}\n"
"#game1, #game2, #game3{\n"
"background-color: #031E28;\n"
"border-radius: 10px;\n"
"}\n"
"#image1, #image2, #image3{\n"
"border: 3px solid  #E61F4B;\n"
"} \n"
"#readBtn1, #readBtn2, #readBtn3{\n"
"border-radius: 10px;\n"
"background-color: #E61F4B;\n"
"padding: 7px;\n"
"} \n"
"#readBtn1:pressed, #readBtn2:pressed, #readBtn3:pressed{\n"
"background-color: #060B0E;\n"
"} ")
        self.centralwidget = QWidget(MainWindow)
        self.centralwidget.setObjectName(u"centralwidget")
        self.verticalLayout = QVBoxLayout(self.centralwidget)
        self.verticalLayout.setSpacing(10)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.verticalLayout.setContentsMargins(0, 10, 0, 10)
        self.header = QWidget(self.centralwidget)
        self.header.setObjectName(u"header")
        sizePolicy = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.header.sizePolicy().hasHeightForWidth())
        self.header.setSizePolicy(sizePolicy)
        self.header.setMinimumSize(QSize(0, 60))
        self.header.setMaximumSize(QSize(16777215, 60))
        self.horizontalLayout = QHBoxLayout(self.header)
        self.horizontalLayout.setSpacing(0)
        self.horizontalLayout.setObjectName(u"horizontalLayout")
        self.horizontalLayout.setContentsMargins(0, 0, 0, 0)
        self.widget = QWidget(self.header)
        self.widget.setObjectName(u"widget")
        self.horizontalLayout_3 = QHBoxLayout(self.widget)
        self.horizontalLayout_3.setSpacing(10)
        self.horizontalLayout_3.setObjectName(u"horizontalLayout_3")
        self.horizontalLayout_3.setContentsMargins(0, 0, 0, 0)
        self.ballIcon = QLabel(self.widget)
        self.ballIcon.setObjectName(u"ballIcon")
        sizePolicy1 = QSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)
        sizePolicy1.setHorizontalStretch(0)
        sizePolicy1.setVerticalStretch(0)
        sizePolicy1.setHeightForWidth(self.ballIcon.sizePolicy().hasHeightForWidth())
        self.ballIcon.setSizePolicy(sizePolicy1)
        self.ballIcon.setMinimumSize(QSize(40, 40))
        self.ballIcon.setMaximumSize(QSize(40, 40))
        self.ballIcon.setPixmap(QPixmap(u":/res/soccer.svg"))
        self.ballIcon.setScaledContents(True)
        self.ballIcon.setAlignment(Qt.AlignRight|Qt.AlignTrailing|Qt.AlignVCenter)

        self.horizontalLayout_3.addWidget(self.ballIcon)

        self.title = QLabel(self.widget)
        self.title.setObjectName(u"title")
        font = QFont()
        font.setFamilies([u"Segoe UI Semibold"])
        font.setPointSize(26)
        font.setBold(True)
        self.title.setFont(font)
        self.title.setAlignment(Qt.AlignLeading|Qt.AlignLeft|Qt.AlignVCenter)

        self.horizontalLayout_3.addWidget(self.title)


        self.horizontalLayout.addWidget(self.widget, 0, Qt.AlignHCenter)


        self.verticalLayout.addWidget(self.header)

        self.main = QWidget(self.centralwidget)
        self.main.setObjectName(u"main")
        self.horizontalLayout_2 = QHBoxLayout(self.main)
        self.horizontalLayout_2.setSpacing(10)
        self.horizontalLayout_2.setObjectName(u"horizontalLayout_2")
        self.horizontalLayout_2.setContentsMargins(10, 0, 10, 0)
        self.newsList = QWidget(self.main)
        self.newsList.setObjectName(u"newsList")
        self.verticalLayout_2 = QVBoxLayout(self.newsList)
        self.verticalLayout_2.setSpacing(10)
        self.verticalLayout_2.setObjectName(u"verticalLayout_2")
        self.verticalLayout_2.setContentsMargins(0, 0, 0, 0)
        self.newsBtn = QPushButton(self.newsList)
        self.newsBtn.setObjectName(u"newsBtn")
        sizePolicy2 = QSizePolicy(QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Fixed)
        sizePolicy2.setHorizontalStretch(0)
        sizePolicy2.setVerticalStretch(0)
        sizePolicy2.setHeightForWidth(self.newsBtn.sizePolicy().hasHeightForWidth())
        self.newsBtn.setSizePolicy(sizePolicy2)
        font1 = QFont()
        font1.setFamilies([u"Segoe UI Semibold"])
        font1.setPointSize(14)
        font1.setBold(True)
        self.newsBtn.setFont(font1)
        self.newsBtn.setCursor(QCursor(Qt.PointingHandCursor))
        icon = QIcon()
        icon.addFile(u":/res/globe.svg", QSize(), QIcon.Normal, QIcon.Off)
        self.newsBtn.setIcon(icon)
        self.newsBtn.setIconSize(QSize(20, 20))

        self.verticalLayout_2.addWidget(self.newsBtn, 0, Qt.AlignHCenter)

        self.news1 = QWidget(self.newsList)
        self.news1.setObjectName(u"news1")
        sizePolicy3 = QSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Preferred)
        sizePolicy3.setHorizontalStretch(0)
        sizePolicy3.setVerticalStretch(0)
        sizePolicy3.setHeightForWidth(self.news1.sizePolicy().hasHeightForWidth())
        self.news1.setSizePolicy(sizePolicy3)
        self.horizontalLayout_4 = QHBoxLayout(self.news1)
        self.horizontalLayout_4.setObjectName(u"horizontalLayout_4")
        self.textWidget = QWidget(self.news1)
        self.textWidget.setObjectName(u"textWidget")
        self.verticalLayout_3 = QVBoxLayout(self.textWidget)
        self.verticalLayout_3.setSpacing(0)
        self.verticalLayout_3.setObjectName(u"verticalLayout_3")
        self.verticalLayout_3.setContentsMargins(0, 0, 0, 0)
        self.newsText1 = QPlainTextEdit(self.textWidget)
        self.newsText1.setObjectName(u"newsText1")
        sizePolicy4 = QSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Expanding)
        sizePolicy4.setHorizontalStretch(0)
        sizePolicy4.setVerticalStretch(0)
        sizePolicy4.setHeightForWidth(self.newsText1.sizePolicy().hasHeightForWidth())
        self.newsText1.setSizePolicy(sizePolicy4)
        font2 = QFont()
        font2.setFamilies([u"Segoe UI Semibold"])
        font2.setPointSize(12)
        font2.setBold(True)
        self.newsText1.setFont(font2)
        self.newsText1.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.newsText1.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.newsText1.setReadOnly(True)
        self.newsText1.setTextInteractionFlags(Qt.NoTextInteraction)

        self.verticalLayout_3.addWidget(self.newsText1)

        self.readBtn1 = QPushButton(self.textWidget)
        self.readBtn1.setObjectName(u"readBtn1")
        self.readBtn1.setMinimumSize(QSize(150, 0))
        self.readBtn1.setMaximumSize(QSize(150, 16777215))
        font3 = QFont()
        font3.setFamilies([u"Segoe UI Semibold"])
        font3.setPointSize(10)
        font3.setBold(True)
        self.readBtn1.setFont(font3)
        self.readBtn1.setCursor(QCursor(Qt.PointingHandCursor))

        self.verticalLayout_3.addWidget(self.readBtn1, 0, Qt.AlignLeft)


        self.horizontalLayout_4.addWidget(self.textWidget)

        self.image1 = QLabel(self.news1)
        self.image1.setObjectName(u"image1")
        self.image1.setMinimumSize(QSize(200, 130))
        self.image1.setMaximumSize(QSize(200, 130))
        self.image1.setScaledContents(True)

        self.horizontalLayout_4.addWidget(self.image1)


        self.verticalLayout_2.addWidget(self.news1)

        self.news2 = QWidget(self.newsList)
        self.news2.setObjectName(u"news2")
        sizePolicy3.setHeightForWidth(self.news2.sizePolicy().hasHeightForWidth())
        self.news2.setSizePolicy(sizePolicy3)
        self.horizontalLayout_9 = QHBoxLayout(self.news2)
        self.horizontalLayout_9.setObjectName(u"horizontalLayout_9")
        self.textWidget_6 = QWidget(self.news2)
        self.textWidget_6.setObjectName(u"textWidget_6")
        self.verticalLayout_10 = QVBoxLayout(self.textWidget_6)
        self.verticalLayout_10.setSpacing(0)
        self.verticalLayout_10.setObjectName(u"verticalLayout_10")
        self.verticalLayout_10.setContentsMargins(0, 0, 0, 0)
        self.newsText2 = QPlainTextEdit(self.textWidget_6)
        self.newsText2.setObjectName(u"newsText2")
        sizePolicy4.setHeightForWidth(self.newsText2.sizePolicy().hasHeightForWidth())
        self.newsText2.setSizePolicy(sizePolicy4)
        self.newsText2.setFont(font2)
        self.newsText2.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.newsText2.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.newsText2.setReadOnly(True)
        self.newsText2.setTextInteractionFlags(Qt.NoTextInteraction)

        self.verticalLayout_10.addWidget(self.newsText2)

        self.readBtn2 = QPushButton(self.textWidget_6)
        self.readBtn2.setObjectName(u"readBtn2")
        self.readBtn2.setMinimumSize(QSize(150, 0))
        self.readBtn2.setMaximumSize(QSize(150, 16777215))
        self.readBtn2.setFont(font3)
        self.readBtn2.setCursor(QCursor(Qt.PointingHandCursor))

        self.verticalLayout_10.addWidget(self.readBtn2, 0, Qt.AlignLeft)


        self.horizontalLayout_9.addWidget(self.textWidget_6)

        self.image2 = QLabel(self.news2)
        self.image2.setObjectName(u"image2")
        self.image2.setMinimumSize(QSize(200, 130))
        self.image2.setMaximumSize(QSize(200, 130))
        self.image2.setScaledContents(True)

        self.horizontalLayout_9.addWidget(self.image2)


        self.verticalLayout_2.addWidget(self.news2)

        self.news3 = QWidget(self.newsList)
        self.news3.setObjectName(u"news3")
        sizePolicy3.setHeightForWidth(self.news3.sizePolicy().hasHeightForWidth())
        self.news3.setSizePolicy(sizePolicy3)
        self.horizontalLayout_10 = QHBoxLayout(self.news3)
        self.horizontalLayout_10.setObjectName(u"horizontalLayout_10")
        self.textWidget_7 = QWidget(self.news3)
        self.textWidget_7.setObjectName(u"textWidget_7")
        self.verticalLayout_11 = QVBoxLayout(self.textWidget_7)
        self.verticalLayout_11.setSpacing(0)
        self.verticalLayout_11.setObjectName(u"verticalLayout_11")
        self.verticalLayout_11.setContentsMargins(0, 0, 0, 0)
        self.newsText3 = QPlainTextEdit(self.textWidget_7)
        self.newsText3.setObjectName(u"newsText3")
        sizePolicy4.setHeightForWidth(self.newsText3.sizePolicy().hasHeightForWidth())
        self.newsText3.setSizePolicy(sizePolicy4)
        self.newsText3.setFont(font2)
        self.newsText3.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.newsText3.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.newsText3.setReadOnly(True)
        self.newsText3.setTextInteractionFlags(Qt.NoTextInteraction)

        self.verticalLayout_11.addWidget(self.newsText3)

        self.readBtn3 = QPushButton(self.textWidget_7)
        self.readBtn3.setObjectName(u"readBtn3")
        self.readBtn3.setMinimumSize(QSize(150, 0))
        self.readBtn3.setMaximumSize(QSize(150, 16777215))
        self.readBtn3.setFont(font3)
        self.readBtn3.setCursor(QCursor(Qt.PointingHandCursor))

        self.verticalLayout_11.addWidget(self.readBtn3, 0, Qt.AlignLeft)


        self.horizontalLayout_10.addWidget(self.textWidget_7)

        self.image3 = QLabel(self.news3)
        self.image3.setObjectName(u"image3")
        self.image3.setMinimumSize(QSize(200, 130))
        self.image3.setMaximumSize(QSize(200, 130))
        self.image3.setScaledContents(True)

        self.horizontalLayout_10.addWidget(self.image3)


        self.verticalLayout_2.addWidget(self.news3)


        self.horizontalLayout_2.addWidget(self.newsList)

        self.gamesList_2 = QWidget(self.main)
        self.gamesList_2.setObjectName(u"gamesList_2")
        sizePolicy3.setHeightForWidth(self.gamesList_2.sizePolicy().hasHeightForWidth())
        self.gamesList_2.setSizePolicy(sizePolicy3)
        self.verticalLayout_4 = QVBoxLayout(self.gamesList_2)
        self.verticalLayout_4.setSpacing(10)
        self.verticalLayout_4.setObjectName(u"verticalLayout_4")
        self.verticalLayout_4.setContentsMargins(0, 0, 0, 0)
        self.gamesBtn = QPushButton(self.gamesList_2)
        self.gamesBtn.setObjectName(u"gamesBtn")
        self.gamesBtn.setFont(font1)
        self.gamesBtn.setCursor(QCursor(Qt.PointingHandCursor))
        icon1 = QIcon()
        icon1.addFile(u":/res/calendar.svg", QSize(), QIcon.Normal, QIcon.Off)
        self.gamesBtn.setIcon(icon1)
        self.gamesBtn.setIconSize(QSize(20, 20))

        self.verticalLayout_4.addWidget(self.gamesBtn, 0, Qt.AlignHCenter)

        self.game1 = QWidget(self.gamesList_2)
        self.game1.setObjectName(u"game1")
        sizePolicy4.setHeightForWidth(self.game1.sizePolicy().hasHeightForWidth())
        self.game1.setSizePolicy(sizePolicy4)
        self.verticalLayout_7 = QVBoxLayout(self.game1)
        self.verticalLayout_7.setSpacing(10)
        self.verticalLayout_7.setObjectName(u"verticalLayout_7")
        self.verticalLayout_7.setContentsMargins(10, 10, 10, 10)
        self.champ1 = QLabel(self.game1)
        self.champ1.setObjectName(u"champ1")
        self.champ1.setFont(font1)
        self.champ1.setAlignment(Qt.AlignCenter)

        self.verticalLayout_7.addWidget(self.champ1, 0, Qt.AlignTop)

        self.stage1 = QLabel(self.game1)
        self.stage1.setObjectName(u"stage1")
        font4 = QFont()
        font4.setFamilies([u"Segoe UI Semilight"])
        font4.setPointSize(12)
        font4.setBold(False)
        self.stage1.setFont(font4)
        self.stage1.setAlignment(Qt.AlignCenter)

        self.verticalLayout_7.addWidget(self.stage1)

        self.date1 = QLabel(self.game1)
        self.date1.setObjectName(u"date1")
        self.date1.setFont(font4)
        self.date1.setAlignment(Qt.AlignCenter)

        self.verticalLayout_7.addWidget(self.date1)

        self.verticalSpacer = QSpacerItem(20, 100, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.verticalLayout_7.addItem(self.verticalSpacer)

        self.teams1 = QLabel(self.game1)
        self.teams1.setObjectName(u"teams1")
        font5 = QFont()
        font5.setFamilies([u"Yu Gothic UI Semibold"])
        font5.setPointSize(12)
        font5.setBold(True)
        self.teams1.setFont(font5)
        self.teams1.setAlignment(Qt.AlignCenter)

        self.verticalLayout_7.addWidget(self.teams1)


        self.verticalLayout_4.addWidget(self.game1)

        self.game2 = QWidget(self.gamesList_2)
        self.game2.setObjectName(u"game2")
        self.verticalLayout_9 = QVBoxLayout(self.game2)
        self.verticalLayout_9.setSpacing(10)
        self.verticalLayout_9.setObjectName(u"verticalLayout_9")
        self.verticalLayout_9.setContentsMargins(10, 10, 10, 10)
        self.champ2 = QLabel(self.game2)
        self.champ2.setObjectName(u"champ2")
        self.champ2.setFont(font1)
        self.champ2.setAlignment(Qt.AlignCenter)

        self.verticalLayout_9.addWidget(self.champ2, 0, Qt.AlignTop)

        self.stage2 = QLabel(self.game2)
        self.stage2.setObjectName(u"stage2")
        self.stage2.setFont(font4)
        self.stage2.setAlignment(Qt.AlignCenter)

        self.verticalLayout_9.addWidget(self.stage2)

        self.date2 = QLabel(self.game2)
        self.date2.setObjectName(u"date2")
        self.date2.setFont(font4)
        self.date2.setAlignment(Qt.AlignCenter)

        self.verticalLayout_9.addWidget(self.date2)

        self.verticalSpacer_3 = QSpacerItem(20, 100, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.verticalLayout_9.addItem(self.verticalSpacer_3)

        self.teams2 = QLabel(self.game2)
        self.teams2.setObjectName(u"teams2")
        self.teams2.setFont(font5)
        self.teams2.setAlignment(Qt.AlignCenter)

        self.verticalLayout_9.addWidget(self.teams2)


        self.verticalLayout_4.addWidget(self.game2)

        self.game3 = QWidget(self.gamesList_2)
        self.game3.setObjectName(u"game3")
        self.verticalLayout_12 = QVBoxLayout(self.game3)
        self.verticalLayout_12.setSpacing(10)
        self.verticalLayout_12.setObjectName(u"verticalLayout_12")
        self.verticalLayout_12.setContentsMargins(10, 10, 10, 10)
        self.champ3 = QLabel(self.game3)
        self.champ3.setObjectName(u"champ3")
        self.champ3.setFont(font1)
        self.champ3.setAlignment(Qt.AlignCenter)

        self.verticalLayout_12.addWidget(self.champ3, 0, Qt.AlignTop)

        self.stage3 = QLabel(self.game3)
        self.stage3.setObjectName(u"stage3")
        self.stage3.setFont(font4)
        self.stage3.setAlignment(Qt.AlignCenter)

        self.verticalLayout_12.addWidget(self.stage3)

        self.date3 = QLabel(self.game3)
        self.date3.setObjectName(u"date3")
        self.date3.setFont(font4)
        self.date3.setAlignment(Qt.AlignCenter)

        self.verticalLayout_12.addWidget(self.date3)

        self.verticalSpacer_4 = QSpacerItem(20, 100, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.verticalLayout_12.addItem(self.verticalSpacer_4)

        self.teams3 = QLabel(self.game3)
        self.teams3.setObjectName(u"teams3")
        self.teams3.setFont(font5)
        self.teams3.setAlignment(Qt.AlignCenter)

        self.verticalLayout_12.addWidget(self.teams3)


        self.verticalLayout_4.addWidget(self.game3)


        self.horizontalLayout_2.addWidget(self.gamesList_2)


        self.verticalLayout.addWidget(self.main)

        MainWindow.setCentralWidget(self.centralwidget)
#if QT_CONFIG(shortcut)
#endif // QT_CONFIG(shortcut)

        self.retranslateUi(MainWindow)

        QMetaObject.connectSlotsByName(MainWindow)
    # setupUi

    def retranslateUi(self, MainWindow):
        MainWindow.setWindowTitle(QCoreApplication.translate("MainWindow", u"SoccerManager", None))
        self.ballIcon.setText("")
        self.title.setText(QCoreApplication.translate("MainWindow", u"SoccerManager", None))
        self.newsBtn.setText(QCoreApplication.translate("MainWindow", u"NEWS", None))
        self.newsText1.setPlainText(QCoreApplication.translate("MainWindow", u"Newsq wefwgr qdwfergwv  2rq2eqwe wrqe", None))
        self.readBtn1.setText(QCoreApplication.translate("MainWindow", u"\u0427\u0438\u0442\u0430\u0442\u044c", None))
        self.image1.setText("")
        self.newsText2.setPlainText(QCoreApplication.translate("MainWindow", u"Newsq wefwgr qdwfergwv  2rq2eqwe wrqe", None))
        self.readBtn2.setText(QCoreApplication.translate("MainWindow", u"\u0427\u0438\u0442\u0430\u0442\u044c", None))
        self.image2.setText("")
        self.newsText3.setPlainText(QCoreApplication.translate("MainWindow", u"Newsq wefwgr qdwfergwv  2rq2eqwe wrqe", None))
        self.readBtn3.setText(QCoreApplication.translate("MainWindow", u"\u0427\u0438\u0442\u0430\u0442\u044c", None))
        self.image3.setText("")
        self.gamesBtn.setText(QCoreApplication.translate("MainWindow", u"GAMES", None))
        self.champ1.setText(QCoreApplication.translate("MainWindow", u"\u041b\u0438\u0433\u0430 \u0447\u0435\u043c\u043f\u0438\u043e\u043d\u043e\u0432", None))
        self.stage1.setText(QCoreApplication.translate("MainWindow", u"\u0424\u0438\u043d\u0430\u043b", None))
        self.date1.setText(QCoreApplication.translate("MainWindow", u"22.05.2024 18:00", None))
        self.teams1.setText(QCoreApplication.translate("MainWindow", u"\u0420\u0435\u0430\u043b - \u0411\u0430\u0440\u0441\u0435\u043b\u043e\u043d\u0430", None))
        self.champ2.setText(QCoreApplication.translate("MainWindow", u"\u041b\u0438\u0433\u0430 \u0447\u0435\u043c\u043f\u0438\u043e\u043d\u043e\u0432", None))
        self.stage2.setText(QCoreApplication.translate("MainWindow", u"\u0424\u0438\u043d\u0430\u043b", None))
        self.date2.setText(QCoreApplication.translate("MainWindow", u"22.05.2024 18:00", None))
        self.teams2.setText(QCoreApplication.translate("MainWindow", u"\u0420\u0435\u0430\u043b - \u0411\u0430\u0440\u0441\u0435\u043b\u043e\u043d\u0430", None))
        self.champ3.setText(QCoreApplication.translate("MainWindow", u"\u041b\u0438\u0433\u0430 \u0447\u0435\u043c\u043f\u0438\u043e\u043d\u043e\u0432", None))
        self.stage3.setText(QCoreApplication.translate("MainWindow", u"\u0424\u0438\u043d\u0430\u043b", None))
        self.date3.setText(QCoreApplication.translate("MainWindow", u"22.05.2024 18:00", None))
        self.teams3.setText(QCoreApplication.translate("MainWindow", u"\u0420\u0435\u0430\u043b - \u0411\u0430\u0440\u0441\u0435\u043b\u043e\u043d\u0430", None))
    # retranslateUi

