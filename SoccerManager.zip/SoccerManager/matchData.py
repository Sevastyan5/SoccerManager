class MatchData:
    def __init__(self):
        super(MatchData, self).__init__()
        self.championship = ''
        self.team1 = ''
        self.team2 = ''
        self.time = ''
        self.stage = ''
